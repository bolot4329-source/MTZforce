package com.bluequark.mtzforge

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bluequark.mtzforge.core.IconColors
import com.bluequark.mtzforge.core.IconRecolor
import com.bluequark.mtzforge.core.MtzTheme
import com.bluequark.mtzforge.core.PsdReader
import com.bluequark.mtzforge.core.Raster
import com.bluequark.mtzforge.core.ThemeIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

enum class Origin(val title: String) { PSD("из PSD"), MTZ("из темы"), PNG("PNG") }

/** Один значок в редакторе. */
data class IconItem(
    val id: Long,
    val name: String,
    val pkg: String?,
    val autoMatched: Boolean,
    val origin: Origin,
    val basePkg: String?,          // для значков из темы-основы: исходный пакет
    val replaced: Boolean,         // картинку заменили на PNG
    val source: ByteArray,         // исходник (PNG, до 512 px)
    val thumb: Raster,             // миниатюра для сетки
    val colors: IconColors,        // найденные цвета фона/логотипа
    val bg: Int? = null,           // новый цвет фона (null — как было)
    val logo: Int? = null,         // новый цвет логотипа (null — как было)
) {
    val modified: Boolean get() = bg != null || logo != null || replaced || pkg != basePkg
}

class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap?)

data class UiState(
    val icons: List<IconItem> = emptyList(),
    val busy: String? = null,
    val progress: Float? = null,
    val message: String? = null,
    val psdName: String? = null,
    val baseTitle: String? = null,
    val psdMode: PsdReader.Mode = PsdReader.Mode.AUTO,
    val title: String = "Моя тема",
    val author: String = "",
    val outSize: Int = 432,
    val apps: List<AppInfo> = emptyList(),
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var nextId = 1L
    private var base: MtzTheme? = null
    private val ctx get() = getApplication<Application>()

    init {
        viewModelScope.launch(Dispatchers.IO) { loadApps() }
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }
    fun setPsdMode(m: PsdReader.Mode) = _state.update { it.copy(psdMode = m) }
    fun setTitle(t: String) = _state.update { it.copy(title = t) }
    fun setAuthor(a: String) = _state.update { it.copy(author = a) }
    fun setOutSize(s: Int) = _state.update { it.copy(outSize = s) }

    fun appLabel(pkg: String?): String? = pkg?.let { p -> _state.value.apps.firstOrNull { it.pkg == p }?.label }

    // ------------------------------------------------------------------ загрузка

    private fun displayName(uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val v = c.getString(0)
                    if (!v.isNullOrBlank()) return v
                }
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val f = File(ctx.cacheDir, name)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            f.outputStream().use { input.copyTo(it, 1 shl 16) }
        } ?: throw IllegalStateException("Не удалось открыть файл")
        return f
    }

    private fun task(busy: String, block: suspend () -> Unit) {
        viewModelScope.launch(Dispatchers.Default) {
            _state.update { it.copy(busy = busy, progress = null) }
            try {
                block()
            } catch (e: OutOfMemoryError) {
                _state.update { it.copy(message = "Не хватило памяти. Попробуйте PSD поменьше или режим «По слоям»") }
            } catch (e: Exception) {
                _state.update { it.copy(message = "Ошибка: ${e.message ?: e.javaClass.simpleName}") }
            } finally {
                _state.update { it.copy(busy = null, progress = null) }
            }
        }
    }

    private fun makeItem(name: String, raster: Raster, origin: Origin, pkg: String?, basePkg: String?, auto: Boolean): IconItem {
        var src = raster.toSquare()
        if (src.width > 512) src = src.scaleTo(512, 512)
        val colors = IconRecolor.analyze(src)
        return IconItem(
            id = nextId++, name = name, pkg = pkg, autoMatched = auto, origin = origin, basePkg = basePkg,
            replaced = false, source = AndroidPng.encode(src), thumb = src.scaleTo(128, 128), colors = colors,
        )
    }

    fun loadPsd(uri: Uri) = task("Читаю PSD…") {
        val name = displayName(uri)
        val file = copyToCache(uri, "source.psd")
        val newItems = mutableListOf<IconItem>()
        val res = try {
            PsdReader(file).read(
                mode = _state.value.psdMode,
                onProgress = { i, n ->
                    _state.update { it.copy(progress = if (n == 0) null else i.toFloat() / n, busy = "Вырезаю значки… $i из $n") }
                },
                onIcon = { ic ->
                    val (pkg, auto) = matchPackage(ic.name)
                    newItems += makeItem(ic.name, ic.raster, Origin.PSD, pkg, null, auto)
                }
            )
        } finally {
            file.delete()
        }
        val newPkgs = newItems.mapNotNull { it.pkg }.toSet()
        _state.update { s ->
            s.copy(
                icons = s.icons.filter { it.origin != Origin.PSD && (it.pkg == null || it.pkg !in newPkgs) } + newItems,
                psdName = name,
                message = buildString {
                    append("Найдено значков: ${newItems.size}")
                    val noPkg = newItems.count { it.pkg == null }
                    if (noPkg > 0) append(", без приложения: $noPkg")
                    append(if (res.usedComposite) " · как в Photoshop" else " · по слоям")
                    res.warnings.firstOrNull()?.let { append("\n").append(it) }
                }
            )
        }
    }

    fun loadBaseMtz(uri: Uri) = task("Открываю тему…") {
        val name = displayName(uri)
        val file = copyToCache(uri, "base.mtz")
        val theme = MtzTheme.read(file)
        base = theme
        val existing = _state.value.icons.mapNotNull { it.pkg }.toSet()
        val baseIcons = theme.appIcons()
        val items = baseIcons.filter { it.pkg !in existing }.mapIndexedNotNull { i, ti ->
            _state.update { it.copy(progress = i.toFloat() / baseIcons.size.coerceAtLeast(1)) }
            try { makeItem(ti.pkg, AndroidPng.decode(ti.png), Origin.MTZ, ti.pkg, ti.pkg, false) } catch (e: Exception) { null }
        }
        _state.update { s ->
            s.copy(
                icons = s.icons.filter { it.origin != Origin.MTZ } + items,
                baseTitle = theme.title ?: name,
                title = if (s.title == "Моя тема" && theme.title != null) theme.title + " (мод)" else s.title,
                message = "Тема-основа: ${theme.title ?: name} · значков в ней: ${baseIcons.size}"
            )
        }
    }

    fun clearBase() {
        base = null
        _state.update { s -> s.copy(baseTitle = null, icons = s.icons.filter { it.origin != Origin.MTZ }) }
    }

    fun addPngs(uris: List<Uri>) = task("Добавляю картинки…") {
        val items = uris.mapNotNull { uri ->
            try {
                val n = displayName(uri).substringBeforeLast('.')
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@mapNotNull null
                val (pkg, auto) = matchPackage(n)
                makeItem(n, AndroidPng.decode(bytes), Origin.PNG, pkg, null, auto)
            } catch (e: Exception) { null }
        }
        val pkgs = items.mapNotNull { it.pkg }.toSet()
        _state.update { s ->
            s.copy(
                icons = s.icons.filter { it.pkg == null || it.pkg !in pkgs } + items,
                message = "Добавлено картинок: ${items.size}" + items.count { it.pkg == null }.let { if (it > 0) ", выберите для них приложение (значки с красной подписью)" else "" }
            )
        }
    }

    fun replaceWithPng(id: Long, uri: Uri) = task("Заменяю значок…") {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@task
        var src = AndroidPng.decode(bytes).toSquare()
        if (src.width > 512) src = src.scaleTo(512, 512)
        val colors = IconRecolor.analyze(src)
        val png = AndroidPng.encode(src)
        val thumb = src.scaleTo(128, 128)
        updateItem(id) { it.copy(source = png, thumb = thumb, colors = colors, bg = null, logo = null, replaced = true) }
    }

    // ------------------------------------------------------------------ правка

    private fun updateItem(id: Long, f: (IconItem) -> IconItem) =
        _state.update { s -> s.copy(icons = s.icons.map { if (it.id == id) f(it) else it }) }

    fun setBg(id: Long, c: Int?) = updateItem(id) { it.copy(bg = c) }
    fun setLogo(id: Long, c: Int?) = updateItem(id) { it.copy(logo = c) }
    fun resetColors(id: Long) = updateItem(id) { it.copy(bg = null, logo = null) }
    fun setAllBg(c: Int?) = _state.update { s -> s.copy(icons = s.icons.map { it.copy(bg = c) }) }
    fun setAllLogo(c: Int?) = _state.update { s -> s.copy(icons = s.icons.map { it.copy(logo = c) }) }
    fun resetAllColors() = _state.update { s -> s.copy(icons = s.icons.map { it.copy(bg = null, logo = null) }) }

    fun setPackage(id: Long, pkg: String) {
        val p = pkg.trim()
        if (p.isEmpty()) return
        _state.update { s ->
            // у одного приложения может быть только один значок
            val others = s.icons.filter { it.id != id && it.pkg == p }
            s.copy(
                icons = s.icons.filter { it !in others }.map { if (it.id == id) it.copy(pkg = p, autoMatched = false) else it },
                message = if (others.isNotEmpty()) "Прежний значок для $p убран" else null
            )
        }
    }

    fun remove(id: Long) = _state.update { s -> s.copy(icons = s.icons.filter { it.id != id }) }

    fun clearAll() {
        base = null
        _state.update { s -> s.copy(icons = emptyList(), psdName = null, baseTitle = null) }
    }

    // ------------------------------------------------------------------ экспорт

    fun export(uri: Uri, sys: SysViewModel) = task("Собираю MTZ…") {
        val s = _state.value
        val theme = base
        val size = s.outSize
        // последний значок для пакета побеждает
        val withPkg = s.icons.filter { it.pkg != null }.reversed().distinctBy { it.pkg }.reversed()
        val toWrite = withPkg.filter { theme == null || it.origin != Origin.MTZ || it.modified }
        val icons = toWrite.mapIndexed { i, item ->
            _state.update { st -> st.copy(progress = i.toFloat() / toWrite.size.coerceAtLeast(1), busy = "Собираю MTZ… $i из ${toWrite.size}") }
            val src = AndroidPng.decode(item.source)
            val out = IconRecolor.recolor(src, item.colors, item.bg, item.logo).scaleTo(size, size)
            ThemeIcon(item.pkg!!, AndroidPng.encode(out))
        }
        val basePkgs = theme?.appIcons()?.map { it.pkg }?.toSet() ?: emptySet()
        val removed = basePkgs - withPkg.mapNotNull { it.pkg }.toSet()
        val preview = if (withPkg.isEmpty()) null else AndroidPng.encode(Raster.grid(
            withPkg.take(24).map { IconRecolor.recolor(it.thumb, it.colors, it.bg, it.logo) },
            cols = 4, cell = 128, gap = 22, background = 0xFF0E0E10.toInt()
        ))
        _state.update { it.copy(progress = null) }
        val modules = sys.buildModules { msg -> _state.update { st -> st.copy(busy = msg) } }
        _state.update { it.copy(busy = "Записываю файл…") }
        ctx.contentResolver.openOutputStream(uri)?.use { out ->
            MtzTheme.write(out, theme, icons, removed, s.title, s.author, preview, modules)
        } ?: throw IllegalStateException("Не удалось сохранить файл")
        val skipped = s.icons.count { it.pkg == null }
        _state.update {
            it.copy(message = "Готово! Значков рабочего стола: ${icons.size}" +
                    (if (modules.isNotEmpty()) ", картинок внутри приложений: ${modules.size}" else "") +
                    (if (theme != null) " (+ ${withPkg.size - toWrite.size} без изменений из темы)" else "") +
                    (if (skipped > 0) "\nПропущено без приложения: $skipped" else ""))
        }
    }

    // ------------------------------------------------------------------ приложения

    private fun loadApps() {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = try {
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        } catch (e: Exception) { emptyList() }
        // если у пакета несколько значков на рабочем столе (Телефон и Контакты в com.android.contacts),
        // каждый получает своё имя: пакет.Активность — так их различают темы MIUI/HyperOS
        val multi = list.groupBy { it.activityInfo.packageName }.filterValues { it.size > 1 }.keys
        val apps = list.distinctBy { it.activityInfo.packageName + "/" + it.activityInfo.name }.map { ri ->
            val pkg = if (ri.activityInfo.packageName in multi) ri.activityInfo.name else ri.activityInfo.packageName
            val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
            val icon = try {
                val d = ri.loadIcon(pm)
                val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                d.setBounds(0, 0, 96, 96)
                d.draw(c)
                bmp.asImageBitmap()
            } catch (e: Exception) { null }
            AppInfo(label, pkg, icon)
        }.sortedBy { it.label.lowercase() }
        _state.update { s ->
            // доподбираем пакеты для уже загруженных значков
            val fixed = s.icons.map { ic ->
                if (ic.pkg != null) ic else {
                    val (p, auto) = matchPackage(ic.name, apps)
                    if (p != null) ic.copy(pkg = p, autoMatched = auto) else ic
                }
            }
            s.copy(apps = apps, icons = fixed)
        }
    }

    private val pkgRegex = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")

    private fun norm(s: String): String =
        s.lowercase()
            .replace(Regex("^(blue|ic|icon|app|oled)[_\\- ]+"), "")
            .replace(Regex("[^\\p{L}\\p{N}]"), "")

    /** Подбор пакета по имени слоя/файла: «com.android.chrome», «Telegram», «blue_youtube»… */
    private fun matchPackage(rawName: String, apps: List<AppInfo> = _state.value.apps): Pair<String?, Boolean> {
        val name = rawName.trim().removeSuffix(".png").removeSuffix(".PNG")
        if (pkgRegex.matches(name)) return name to false
        val n = norm(name)
        if (n.length < 3) return null to false
        apps.firstOrNull { norm(it.label) == n }?.let { return it.pkg to true }
        apps.firstOrNull { a -> a.pkg.lowercase().split('.').any { it == n } }?.let { return it.pkg to true }
        if (n.length >= 4) {
            apps.firstOrNull { a -> val l = norm(a.label); l.length >= 4 && (l.startsWith(n) || n.startsWith(l)) }
                ?.let { return it.pkg to true }
        }
        return null to false
    }
}
