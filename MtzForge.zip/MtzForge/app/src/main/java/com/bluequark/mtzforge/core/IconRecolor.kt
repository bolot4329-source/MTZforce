package com.bluequark.mtzforge.core

import kotlin.math.sqrt

/** Найденные в значке цвета: фон (самый частый) и логотип (самый частый из заметно отличающихся). */
data class IconColors(val bg: Int, val logo: Int?)

object IconRecolor {

    fun analyze(r: Raster): IconColors {
        val counts = IntArray(1 shl 15)
        val sumR = LongArray(1 shl 15); val sumG = LongArray(1 shl 15); val sumB = LongArray(1 shl 15)
        var opaque = 0
        for (p in r.pixels) {
            if ((p ushr 24) < 250) continue
            val rr = (p shr 16) and 0xFF; val gg = (p shr 8) and 0xFF; val bb = p and 0xFF
            val k = ((rr shr 3) shl 10) or ((gg shr 3) shl 5) or (bb shr 3)
            counts[k]++; sumR[k] += rr.toLong(); sumG[k] += gg.toLong(); sumB[k] += bb.toLong()
            opaque++
        }
        if (opaque == 0) return IconColors(0xFF000000.toInt(), null)
        fun avg(k: Int) = Raster.argb(255, (sumR[k] / counts[k]).toInt(), (sumG[k] / counts[k]).toInt(), (sumB[k] / counts[k]).toInt())
        var best = 0
        for (k in counts.indices) if (counts[k] > counts[best]) best = k
        val bg = avg(best)
        var logoK = -1
        for (k in counts.indices) {
            if (counts[k] == 0) continue
            if (dist(avg(k), bg) < 80.0) continue
            if (logoK < 0 || counts[k] > counts[logoK]) logoK = k
        }
        val logo = if (logoK >= 0 && counts[logoK] * 400 >= opaque) avg(logoK) else null
        return IconColors(bg, logo)
    }

    /**
     * Перекраска. newBg/newLogo == null — оставить как было.
     * Каждый пиксель раскладывается на «долю фона» и «долю логотипа» по расстоянию от цвета фона,
     * поэтому сглаженные края остаются чистыми.
     */
    fun recolor(src: Raster, colors: IconColors, newBg: Int?, newLogo: Int?): Raster {
        if (newBg == null && newLogo == null) return src
        val out = Raster(src.width, src.height)
        val bg = colors.bg
        val bgR = (bg shr 16) and 0xFF; val bgG = (bg shr 8) and 0xFF; val bgB = bg and 0xFF
        val ref = (colors.logo?.let { dist(it, bg) } ?: 120.0).coerceAtLeast(40.0)
        val tol = 6.0
        val nb = newBg ?: bg
        val nbR = (nb shr 16) and 0xFF; val nbG = (nb shr 8) and 0xFF; val nbB = nb and 0xFF
        val nl = newLogo ?: 0
        val nlR = (nl shr 16) and 0xFF; val nlG = (nl shr 8) and 0xFF; val nlB = nl and 0xFF

        for (i in src.pixels.indices) {
            val p = src.pixels[i]
            val a = p ushr 24
            if (a == 0) { out.pixels[i] = 0; continue }
            val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
            val d = sqrt(((r - bgR) * (r - bgR) + (g - bgG) * (g - bgG) + (b - bgB) * (b - bgB)).toDouble())
            val w = ((d - tol) / (ref - tol)).coerceIn(0.0, 1.0)
            val o = if (newLogo == null) {
                // меняем только фон: p + (1-w)·(новыйФон − фон) — логотип и фактура фона сохраняются
                val k = 1.0 - w
                Raster.argb(a, (r + k * (nbR - bgR)).toInt(), (g + k * (nbG - bgG)).toInt(), (b + k * (nbB - bgB)).toInt())
            } else {
                // логотип заливается новым цветом, фон — новым (или прежним) цветом
                val k = 1.0 - w
                val br = nbR + k * (r - bgR); val bgg = nbG + k * (g - bgG); val bb = nbB + k * (b - bgB)
                Raster.argb(a, (br + w * (nlR - br)).toInt(), (bgg + w * (nlG - bgg)).toInt(), (bb + w * (nlB - bb)).toInt())
            }
            out.pixels[i] = o
        }
        return out
    }

    /** Залить одним цветом с сохранением прозрачности (для одноцветных системных иконок). */
    fun tint(src: Raster, color: Int): Raster {
        val rgb = color and 0xFFFFFF
        val out = Raster(src.width, src.height)
        for (i in src.pixels.indices) {
            val a = src.pixels[i] ushr 24
            out.pixels[i] = if (a == 0) 0 else (a shl 24) or rgb
        }
        return out
    }

    fun dist(c1: Int, c2: Int): Double {
        val dr = ((c1 shr 16) and 0xFF) - ((c2 shr 16) and 0xFF)
        val dg = ((c1 shr 8) and 0xFF) - ((c2 shr 8) and 0xFF)
        val db = (c1 and 0xFF) - (c2 and 0xFF)
        return sqrt((dr * dr + dg * dg + db * db).toDouble())
    }

    fun toHex(c: Int): String = String.format("%06X", c and 0xFFFFFF)

    fun parseHex(s: String): Int? {
        val t = s.trim().removePrefix("#")
        if (t.length != 6) return null
        return t.toLongOrNull(16)?.let { (0xFF000000L or it).toInt() }
    }
}
